package com.examengine.examengine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamEngineApplicationTests {

	@Test
	void contextLoads() {
	}

}
