package com.examengine.examengine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamEngineApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamEngineApplication.class, args);
	}

}
